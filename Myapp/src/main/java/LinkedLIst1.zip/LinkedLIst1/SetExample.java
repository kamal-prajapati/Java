package LinkedLIst1;

import java.util.*;

public class SetExample {
    public static  void main(String args[])
    {
        Set<String> ll=new HashSet<String>();
        ll.add("arun");
        ll.add(null);
        ll.add("kamal");
        ll.add(null);
        ll.add("ankit");
        ll.add("Rahul");
        ll.add("ankit");
        System.out.println(ll);
    }
}
