package LinkedLIst1;

import java.util.*;

public class TreeSetExample {
    public static void main(String args[])
    {
        Set<String> ts=new TreeSet<String>();
        ts.add("Javascript");
        ts.add("Node.js");
        ts.add("Java Hibernate");
        ts.add("Spring");
        ts.add("ORM");
        ts.add("null");
        ts.add("null");
        ts.add("Spring");
        System.out.println(ts);

    }

}
