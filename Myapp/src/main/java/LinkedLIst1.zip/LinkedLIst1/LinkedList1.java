package LinkedLIst1;
import java.util.*;

public class LinkedList1 {
    public static void main(String args[])
    {

        LinkedList<String> list
                = new LinkedList<String>();

        list.add("987439");
        list.add("343");
        list.add("34534");
        list.add("4537");
        list.add("984567");


        System.out.println("The LinkedList: "
                + list);

    }
}